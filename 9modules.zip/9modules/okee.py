import numpy as np
# Original matrix size
original_size = 36
additional_size = 18
new_size = original_size + additional_size

# Create the expanded diagonal matrix
expanded_mass_matrix = np.eye(new_size) * 400

# Print the matrix
np.savetxt("expanded_mass_matrix.txt", expanded_mass_matrix, fmt="%d")
print(expanded_mass_matrix)

